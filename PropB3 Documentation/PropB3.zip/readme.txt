Hallo PropB3 User,

this archive holds all files to build the PropB3 organ.

some infos:
- to programm the chip you will need a serial programmer and the programming software from parallax web site.
  you can build the serial programmer by yourself. -> see "serialtopropeller.pdf". you can also use the original parallax adapter.
  in this way the upper pin with 3,3v is unused.
  if you use the "home made adapter" theres a little dug. first time, after you try to download, you will get no connection via the adapter to
  the chip. you have to try onemore once. then it works

- double click the file "PropB3***.binary" form your windows explorer. The Propeller Tool will be opened and then click
  to "LOAD to EEPROM". Propeller Tool will now connect to the Organ and programm the EEPROM chip.

- the MidiDWB.exe is a small programm to send the Midi controllers for drawbars (i dont have a masterkeyboard with sliders) 
  it can be usefull for the first test.

- If you use the WM8727, you have to solder it on a smal adaptor pcb. Use strip conntacts to connect the smal pcb to the
  main pcb. 

- If you use the TDA1543 dont try it with a TDA1543S. The "S"-type won't work!

- You can connect to the two transistor output relays, so that you can control an external leslie with a midi keyboard.


'#########################################################################################
'Tonewheel Organ on Propeller Chip
'
'Version : 0-F0
'
'Features/performance:
'79 free running Tonewheels, Foldback like Hammond organ, Keyclick simulation,
'Percusion 4' or 2 2/3' on first note, vibrato or chourus effect,
'polyphonie : 16 
'simple Hardware for DIY.
'using a TDA1543 as DAC or Wolfson WM8727 chip
'
'Midi Recieve Channel : 1  (0h)
'Note On/Off          : 36 - 96 (61Keys)
'Midi Controller      : 12 -> Drawbar 16'
'                       13 -> Drawbar 5 1/3'
'                       14 -> Drawbar 8'
'                       15 -> Drawbar 4'
'                       16 -> Drawbar 2 2/3'
'                       17 -> Drawbar 2'
'                       18 -> Drawbar 1 3/5'
'                       19 -> Drawbar 1 1/3'
'                       20 -> Drawbar 1'
'                       31 -> 0=Vib OFF, 8=Vibrato, 16= Chorus '
'                       66 -> 0=Percusion OFF, 8=4th, 16=3rd'
'                       68 -> 0=Leslie OFF, 64=Leslie ON
'                       01 -> 0=Leslie SLOW, 64= Leslie FAST
'                       07 -> Main Volumen
'                       08 -> Balance Rotor / Horn
'                       09 -> Distortion
'                       91 -> Reverb
'#########################################################################################

have fun.
